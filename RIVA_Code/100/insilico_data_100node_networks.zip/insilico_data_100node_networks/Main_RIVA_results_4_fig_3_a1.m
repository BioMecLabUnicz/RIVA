%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script enables to compute the reconstruced connectivity matrices,
% the perturbation vectors B and performance indexes obtained by Riva for 
% the 5 in-silico networks of 100 nodes of Dream4 challenge, using the first 
% half of data, when the perturbation is applied - 10 time-series, each one
% of 11 time points; we replicate the data-set 20 times by adding noise. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear all
close all
% 
% % define the maxinum number of iterations for each identification
% max_iter_num=50;
% 
% % threshold value for the estimation error 
% thr_err=0.1;
% 
% % thereshold value for the estimation error used to compare the performance
% % with CLR
% thr_err_und=0.01;
% 
% % select which networks you want to test
% % n_nodes=10; % test over the networks of ten nodes
n_nodes=100; % test over the networks of twenty nodes 

num_exp=10; % number of time-series for exp.

type_d=2;

if type_d==1
    DREAM4=true; %type of time series
else 
    DREAM4=false; % we divide the original data set in two parts: 1) from 0 to 500; 
                  % 2) from 500 to 1000;
end
% networks number
n_networks=5;

% number of tests:
n_tests=21;

n_modes=1; % type of normalization for ranking, it can be also 2 or 3, see norm_rec_mtx.m


% allocate a memory space to save the output variables of the iterative
% procedure
A_id_cell_LS{n_networks,n_tests}=[]; % cell array containing the identified 
                                     % connectivity matrices, obtained by
                                     % using LS, for each network and 
                                     % test 
                                     
A_id_cell_RLS{n_networks,n_tests}=[]; % cell array containing the identified 
                                     % connectivity matrices, obtained by
                                     % using RLS, for each network and 
                                     % test  

A_id_cell_RLS_IV{n_networks,n_tests}=[]; % cell array containing the identified 
                                     % connectivity matrices, obtained by
                                     % using RLS_IV, for each network and 
                                     % test  


B_id_cell_LS{n_networks,n_tests}=[]; % cell array containing the identified 
                                     % input matrices, obtained by
                                     % using LS, for each network and 
                                     % test 
                                     
B_id_cell_RLS{n_networks,n_tests}=[]; % cell array containing the identified 
                                     % input matrices, obtained by
                                     % using RLS, for each network and 
                                     % test  

B_id_cell_RLS_IV{n_networks,n_tests}=[]; % cell array containing the identified 
                                     % input matrices, obtained by
                                     % using RLS_IV, for each network and 
                                     % test  

est_err_cell_LS{n_networks,n_tests}=[]; % cell array containing  the errors 
                                         % of the identified models, obtained by
                                     % using LS, for each network and 
                                     % test 
                                     
est_err_cell_RLS{n_networks,n_tests}=[]; % cell array containing the errors 
                                         % of the identified models, obtained by
                                     % using RLS, for each network and 
                                     % test  

est_err_cell_RLS_IV{n_networks,n_tests}=[]; % cell array containing the errors 
                                         % of the identified models, obtained by
                                     % using RLS_IV, for each network and 
                                     % test  
                                     
                                     
sol_found_LS{n_networks,n_tests}=[]; % cell array containing  a flag, true
                                      % if a solution has been found, obtained by
                                     % using LS, for each network and 
                                     % test 
                                     
sol_found_RLS{n_networks,n_tests}=[]; % cell array containing a flag, true
                                      % if a solution has been found, obtained by
                                     % using RLS, for each network and 
                                     % test  

sol_found_RLS_IV{n_networks,n_tests}=[]; % cell array containing a flag, true
                                      % if a solution has been found, obtained by
                                     % using RLS_IV, for each network and 
                                     % test 
                                     
                                                                          
A_id_cell_LS1{n_networks,n_tests}=[]; % cell array containing the identified 
                                     % connectivity matrices, obtained by
                                     % using LS1, for each network and 
                                     % test  

A_id_cell_LS1_IV{n_networks,n_tests}=[]; % cell array containing the identified 
                                     % connectivity matrices, obtained by
                                     % using LS1_IV, for each network and 
                                     % test  


B_id_cell_LS1{n_networks,n_tests}=[]; % cell array containing the identified 
                                     % input matrices, obtained by
                                     % using LS1, for each network and 
                                     % test  

B_id_cell_LS1_IV{n_networks,n_tests}=[]; % cell array containing the identified 
                                     % input matrices, obtained by
                                     % using LS1_IV, for each network and 
                                     % test  

est_err_cell_LS1{n_networks,n_tests}=[]; % cell array containing the errors 
                                         % of the identified models, obtained by
                                     % using LS1, for each network and 
                                     % test  

est_err_cell_LS1_IV{n_networks,n_tests}=[]; % cell array containing the errors 
                                         % of the identified models, obtained by
                                     % using LS1_IV, for each network and 
                                     % test  
                                     
                                     
sol_found_LS1{n_networks,n_tests}=[]; % cell array containing a flag, true
                                      % if a solution has been found, obtained by
                                     % using LS1, for each network and 
                                     % test  

sol_found_LS1_IV{n_networks,n_tests}=[]; % cell array containing a flag, true
                                      % if a solution has been found, obtained by
                                     % using LS1_IV, for each network and 
                                     % test 

% define a vector to store the sparsity coefficient for each network
spars_networks=zeros(1,n_networks);

% define array to store the results 
PPV_LS{n_networks,n_tests}=[];
Se_LS{n_networks,n_tests}=[];
Sp_LS{n_networks,n_tests}=[];
FP_LS{n_networks,n_tests}=[];        

PPV_RLS{n_networks,n_tests}=[];
Se_RLS{n_networks,n_tests}=[];
Sp_RLS{n_networks,n_tests}=[];
FP_RLS{n_networks,n_tests}=[];        


PPV_RLS_IV{n_networks,n_tests}=[];
Se_RLS_IV{n_networks,n_tests}=[];
Sp_RLS_IV{n_networks,n_tests}=[];
FP_RLS_IV{n_networks,n_tests}=[];        

PPV_LS1{n_networks,n_tests}=[];
Se_LS1{n_networks,n_tests}=[];
Sp_LS1{n_networks,n_tests}=[];
FP_LS1{n_networks,n_tests}=[];        


PPV_LS1_IV{n_networks,n_tests}=[];
Se_LS1_IV{n_networks,n_tests}=[];
Sp_LS1_IV{n_networks,n_tests}=[];
FP_LS1_IV{n_networks,n_tests}=[];        



% % define a flag (do_sim), true if you choose to do the simulation,
% % otherwise you can load the file.mat, where the identified variables have 
% % been saved
do_sim=false;

%                                     
if not(do_sim)
    
    
   load Data_results_figs_3_4/results/res_Riva_tps11_from_0to500.mat
  
    

else
    
    
    load  Data_results_figs_3_4/Data/Dream4_100nodes_replica.mat
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    %%%%%% COMPUTE THE PERFORMANCE OF LS techniques: LS,LS-IV, RLS, RLS-IV      %%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    for num_net=1:n_networks 

        % load the data for the current network


        eval(['load  Data_results_figs_3_4/Data/DREAM4_GoldStandard_InSilico_Size100_',num2str(num_net),'.mat'])

        n_elem_not_null=nnz(original_network);
        spar_coef=(n_nodes*(n_nodes-1)-n_elem_not_null)/(n_nodes^2-n_nodes);
        %use the following formula if diag is not equal to zero(n_nodes^2-n_elem_not_null)/(n_nodes^2-n_nodes);
        spars_networks(num_net)=spar_coef; 


        for num_test=1:n_tests
            
             
            if num_test==1
            
                    
          
                v_tps=[1:11,22:32,43:53,64:74,85:95,106:116, 127:137, 148:158, 169:179, 190:200];
                 
                %v_tps=[11:21,32:42,53:63,74:84,95:105,116:126, 137:147, 158:168, 179:189, 200:210];

            else
                
                
                v_tps=[1:2:21,42:2:62,83:2:103,124:2:144,165:2:185,206:2:226, 247:2:267, 288:2:308, 329:2:349, 370:2:390];

%               v_tps=[21:2:41,62:2:82,103:2:123,144:2:164,185:2:205,226:2:246, 267:2:287, 308:2:328, 349:2:369, 390:2:410];

        
               
            end
            Meas_mtx_all=rete{num_test,num_net};

            Meas_mtx=Meas_mtx_all(v_tps,2:end);
            B_mtx=[];
            sign_constr_list=[];
                if do_sim
                    % Compute the variables to be identified (the connectivity 
                    % matrix A and the exogenous perturbation vector B)

                    % Inference by using LS, RLS and RLS_IV
                    [A_id_cell,B_id_cell,est_err_cell,sol_found] = ...
                        net_rec_ls_full_iv(Meas_mtx,B_mtx,sign_constr_list,num_exp,DREAM4);            
                    % store the identified variables
                    A_id_cell_LS{num_net,num_test}=A_id_cell{1,1};
                    B_id_cell_LS{num_net,num_test}=B_id_cell{1,1};
                    est_err_cell_LS{num_net,num_test}=est_err_cell{1,1};
                    sol_found_LS{num_net,num_test}=sol_found{1,1};
                    A_id_cell_RLS{num_net,num_test}=A_id_cell{1,2};
                    B_id_cell_RLS{num_net,num_test}=B_id_cell{1,2};
                    est_err_cell_RLS{num_net,num_test}=est_err_cell{1,2};
                    sol_found_RLS{num_net,num_test}=sol_found{1,2};
                    A_id_cell_RLS_IV{num_net,num_test}=A_id_cell{1,3};
                    B_id_cell_RLS_IV{num_net,num_test}=B_id_cell{1,3};
                    est_err_cell_RLS_IV{num_net,num_test}=est_err_cell{1,3};
                    sol_found_RLS_IV{num_net,num_test}=sol_found{1,3};
                else
                    A_id_cell{1,1}=A_id_cell_LS{num_net,num_test};
                    B_id_cell{1,1}=B_id_cell_LS{num_net,num_test};
                    est_err_cell{1,1}=est_err_cell_LS{num_net,num_test};
                    sol_found{1,1}=sol_found_LS{num_net,num_test};
                    A_id_cell{1,2}=A_id_cell_RLS{num_net,num_test};
                    B_id_cell{1,2}=B_id_cell_RLS{num_net,num_test};
                    est_err_cell{1,2}=est_err_cell_RLS{num_net,num_test};
                    sol_found{1,2}=sol_found_RLS{num_net,num_test};
                    A_id_cell{1,3}=A_id_cell_RLS_IV{num_net,num_test};
                    B_id_cell{1,3}=B_id_cell_RLS_IV{num_net,num_test};
                    est_err_cell{1,3}=est_err_cell_RLS_IV{num_net,num_test};
                    sol_found{1,3}=sol_found_RLS_IV{num_net,num_test};


                end

                % evaluation of the performance by calculating the PPV,
                % sensitivity and specificity indexes


                if do_sim
                    % Compute the variables to be identified (the connectivity 
                    % matrix A and the exogenous perturbation vector B)

                    % Inference by using LS, LS1 and LS1_IV
                    [A_id_cell,B_id_cell,est_err_cell,sol_found] = ...
                        net_rec_ls_only_full_iv(Meas_mtx,B_mtx,sign_constr_list,num_exp,DREAM4);            
                    % store the identified variables
                    A_id_cell_LS1{num_net,num_test}=A_id_cell{1,2};
                    B_id_cell_LS1{num_net,num_test}=B_id_cell{1,2};
                    est_err_cell_LS1{num_net,num_test}=est_err_cell{1,2};
                    sol_found_LS1{num_net,num_test}=sol_found{1,2};
                    A_id_cell_LS1_IV{num_net,num_test}=A_id_cell{1,3};
                    B_id_cell_LS1_IV{num_net,num_test}=B_id_cell{1,3};
                    est_err_cell_LS1_IV{num_net,num_test}=est_err_cell{1,3};
                    sol_found_LS1_IV{num_net,num_test}=sol_found{1,3};
                else
                    A_id_cell{1,2}=A_id_cell_LS1{num_net,num_test};
                    B_id_cell{1,2}=B_id_cell_LS1{num_net,num_test};
                    est_err_cell{1,2}=est_err_cell_LS1{num_net,num_test};
                    sol_found{1,2}=sol_found_LS1{num_net,num_test};
                    A_id_cell{1,3}=A_id_cell_LS1_IV{num_net,num_test};
                    B_id_cell{1,3}=B_id_cell_LS1_IV{num_net,num_test};
                    est_err_cell{1,3}=est_err_cell_LS1_IV{num_net,num_test};
                    sol_found{1,3}=sol_found_LS1_IV{num_net,num_test};


                end




            % for a given network, evaluation of the performance by calculating the AUPR and
            % AUROC for each single test 

            for num_mode=1:n_modes

                [AUPR_m AUROC_m PPV Se Sp FP]=val_aupr_auroc_net100(original_network,A_id_cell_LS{num_net,num_test},num_mode);

                eval(['perf_aupr_LS_net_',num2str(num_net),'(num_mode,num_test)=AUPR_m;']);
                eval(['perf_auroc_LS_net_',num2str(num_net),'(num_mode,num_test)=AUROC_m;']);

                PPV_LS{num_net,num_test}=PPV;
                Se_LS{num_net,num_test}=Se;
                Sp_LS{num_net,num_test}=Sp;
                FP_LS{num_net,num_test}=FP;        

                clear AUPR_m AUROC_m PPV Se Sp FP

                [AUPR_m AUROC_m PPV Se Sp FP]=val_aupr_auroc_net100(original_network,A_id_cell_LS1_IV{num_net,num_test},num_mode);

                eval(['perf_aupr_LS1_IV_net_',num2str(num_net),'(num_mode,num_test)=AUPR_m;']);
                eval(['perf_auroc_LS1_IV_net_',num2str(num_net),'(num_mode,num_test)=AUROC_m;']);

                PPV_LS1_IV{num_net,num_test}=PPV;
                Se_LS1_IV{num_net,num_test}=Se;
                Sp_LS1_IV{num_net,num_test}=Sp;
                FP_LS1_IV{num_net,num_test}=FP;        

                clear AUPR_m AUROC_m PPV Se Sp FP

                [AUPR_m AUROC_m PPV Se Sp FP]=val_aupr_auroc_net100(original_network,A_id_cell_RLS{num_net,num_test},num_mode);

                eval(['perf_aupr_RLS_net_',num2str(num_net),'(num_mode,num_test)=AUPR_m;']);
                eval(['perf_auroc_RLS_net_',num2str(num_net),'(num_mode,num_test)=AUROC_m;']);

                PPV_RLS{num_net,num_test}=PPV;
                Se_RLS{num_net,num_test}=Se;
                Sp_RLS{num_net,num_test}=Sp;
                FP_RLS{num_net,num_test}=FP;        

                clear AUPR_m AUROC_m PPV Se Sp FP

                [AUPR_m AUROC_m PPV Se Sp FP]=val_aupr_auroc_net100(original_network,A_id_cell_RLS_IV{num_net,num_test},num_mode);

                eval(['perf_aupr_RLS_IV_net_',num2str(num_net),'(num_mode,num_test)=AUPR_m;']);
                eval(['perf_auroc_RLS_IV_net_',num2str(num_net),'(num_mode,num_test)=AUROC_m;']);


                PPV_RLS_IV{num_net,num_test}=PPV;
                Se_RLS_IV{num_net,num_test}=Se;
                Sp_RLS_IV{num_net,num_test}=Sp;
                FP_RLS_IV{num_net,num_test}=FP;        


                clear AUPR_m AUROC_m PPV Se Sp FP


            end

        end


        save ('Data_results_figs_3_4/results/res_perf_Bempty_tps11_from_0to500.mat')

    end
end



% % For a given network, evaluation of the more likely reconstructed network
% % among all those identified,  
% 
% aupr_Riva=zeros(1,n_networks);
% auroc_Riva=zeros(1,n_networks);
% 
% % number of links to be added for computing performance at each evaluation (idx_eval): from 1 to 9990=sum(inc_coef2add); 
% inc_coef2add=[1 2 2 3 3 4:35 40 50 75 100 200 500 800 1000 1500 2000 3000];
% num_mode=1; %criterion of normalization for ranking, it can be also 2 or 3, see norm_rec_mtx.m
% 
% for num_id_net=1:n_networks
%     num_id=0;
%      Constr_list_cell_net=[];
%     for num_test=1:n_tests
%         sol_found_id=sol_found_RLS_IV{num_id_net,num_test};
%         
%         if sol_found_id
%             
%             A_id_cell=A_id_cell_RLS_IV{num_id_net,num_test};
%             %normalize the identified matrix
%             Normal_A_id = norm_rec_mtx(A_id_cell,num_mode);
%             for idx2=1:n_nodes
%                 Normal_A_id(idx2,idx2)=0;
%             end
%             % sort the matrix coef.
%             [idx_row, idx_col, val_coef]=find(Normal_A_id);
%             [val_coef_sort, idx_sort]=sort(val_coef,'descend');
%             %create the ranking list
%             Constr_list=[idx_row(idx_sort) idx_col(idx_sort) val_coef_sort];
%             
%             num_id=num_id+1;
%             % store the ranking list for a test
%             Constr_list_cell_net{num_id}=Constr_list;
%         end
%                     
%     end
%     
%     if num_id==0
%         for num_test=1:n_tests
%             sol_found_id=sol_found_RLS{num_id_net,num_test};
%             
%             
%             if sol_found_id
%                 A_id_cell=A_id_cell_RLS{num_id_net,num_test};
%                 %normalize the identified matrix
%                 Normal_A_id = norm_rec_mtx(A_id_cell,num_mode);
%                 for idx2=1:n_nodes
%                     Normal_A_id(idx2,idx2)=0;
%                 end
%                 % sort the matrix coef.
%                 [idx_row, idx_col, val_coef]=find(Normal_A_id);
%                 [val_coef_sort, idx_sort]=sort(val_coef,'descend');
%                 %create the ranking list
%                 Constr_list=[idx_row(idx_sort) idx_col(idx_sort) val_coef_sort];
%                 
%                 num_id=num_id+1;
%                 % store the ranking list for a test
%                 Constr_list_cell_net{num_id}=Constr_list;
%             end
%             
%         end
%     end
%     
%     
%     eval(['load  Data_results_figs_3_4/Data/DREAM4_GoldStandard_InSilico_Size100_',num2str(num_id_net),'.mat'])
% 
%     num_eval=length(inc_coef2add);
%     PPV=zeros(1,num_eval);
%     Se=zeros(1,num_eval);
%     Sp=zeros(1,num_eval);
%     FP=zeros(1,num_eval);
%     TN=(n_nodes-1)*n_nodes-nnz(original_network);
% 
%     for idx_eval=1:num_eval
%         
%         A_n_rank=zeros(n_nodes,n_nodes); 
%         num_edges=sum(inc_coef2add(1:idx_eval));% number of edges to be inserted from a given ranking list                           
%         if not(isempty(Constr_list_cell_net))            
%             
%             for idx_id=1:size(Constr_list_cell_net,2) % for all the test with solution
%                 rank_list=Constr_list_cell_net{idx_id}; 
%                
%                 % add to A_n_rank the number of edges to be inserted for a
%                 % given test
%                 for idx_n=1:num_edges
%                     
%                     A_n_rank(rank_list(idx_n,1),rank_list(idx_n,2))=A_n_rank(rank_list(idx_n,1),rank_list(idx_n,2))+1;
%                     
%                     
%                 end
%                 
%                 
%             end
%         end
%         
%         A_n_rank_cell{num_id_net,idx_eval}=A_n_rank;
%         A_id_ones=val_rec_list(A_n_rank,num_edges);
%         [Perf_idx, Res]= ppv_sens_spec(original_network,A_id_ones);
%         PPV(idx_eval)=Perf_idx(2,1);
%         Se(idx_eval)=Perf_idx(2,2);
%         Sp(idx_eval)=Perf_idx(2,3);
%         FP(idx_eval)=size(Res.Dir.False_pos,1);
%         
%     end
%             
%     aupr_Riva(num_id_net)=eval_aupr(PPV,Se);
%     auroc_Riva(num_id_net)=eval_auroc(Se,FP,TN);
%                        
% end
% 
% 
% %%%%%% Plot the performance of RIVA and the other algorithms 
% 
% 
% load Data_results_figs_3_4/results/Bingo_100
% load Data_results_figs_3_4/results/dynGenie3_100
% 
% tag_riva='ob';
% tag_genie='sk';
% tag_bingo='dr';
% 
% for num_id_net=1:5
%    
%     
%    
%     
%     if num_id_net==1
%             name_net='net. 1';
%         elseif num_id_net==2
%             name_net='net. 2';
%         elseif num_id_net==3
%             name_net='net. 3';
%         elseif num_id_net==4
%             name_net='net. 4';
%         elseif num_id_net==5
%             name_net='net. 5';
%     end
%     
%     
%     f=figure;
%     hold on 
%     grid on
%     plot(auroc_Riva(num_id_net),aupr_Riva(num_id_net),tag_riva);
%     plot(Result_dynGenie3100.auroc(num_id_net),Result_dynGenie3100.aupr(num_id_net),tag_genie);
%     plot(Result_Bingo100.auroc(num_id_net),Result_Bingo100.aupr(num_id_net),tag_bingo);
%     xlim([0.5 0.8])
%      
%     ylim([0 0.15])
%     ylabel('AUPR')
%     xlabel('AUROC')
%     title(name_net)
%     set(f,'Position',[10 10 250 250])
%     set(gca,'fontsize',12)
%     
% end
