
function Meas_mtx_flt_all=ljung_mthd(Meas_sim,Err_mtx,num_exp,ord_ar_no_model)

[n_time_pts,n_nodes]=size(Meas_sim);

n_time_pts=n_time_pts/num_exp;

% compute the residual
err_iv=[];
for idx=1:size(Err_mtx,2)
    err_iv_old=err_iv;
    err_iv=[err_iv_old Err_mtx(:,idx)'];
end

% estimate an AR  model for the residuals (err_iv) to extract
% the remaining information from err_iv:
% X_err = Z_err*par_ar_no_model + noise where X_err and Z_err are obtained 
% by the vector err_iv as follows

% size of each Err_mtx_num_ts for each time series
num_tps=size(Err_mtx,2)/num_exp;

if ord_ar_no_model>num_tps
    ord_ar_no_model=num_tps-1;
end

for num_ts=1:num_exp
    eval(['Err_mtx_',num2str(num_ts),'= Err_mtx(:,num_tps*(num_ts-1)+1:num_tps*num_ts);'])
    eval(['err_iv_',num2str(num_ts),'= err_iv(num_tps*(num_ts-1)*n_nodes+1:num_tps*num_ts*n_nodes);'])
end

% vector that contains the columns from 2 to n_time_pts of each
% Err_mtx_num_ts
X_err=zeros(1,(num_tps-1)*n_nodes*num_exp);
for num_ts=1:num_exp
    eval(['X_err((num_tps-1)*n_nodes*(num_ts-1)+1:(num_tps-1)*n_nodes*num_ts)= err_iv_',num2str(num_ts),...
        '(n_nodes+1:num_tps*n_nodes);'])
end
X_err=X_err';
Z_err=[];
for num_ts=1:num_exp
    Z_err_one=zeros((num_tps-1)*n_nodes,ord_ar_no_model);
    for idx=1:ord_ar_no_model
        eval(['Z_err_one(:,idx)=[zeros(1,(idx-1)*n_nodes) err_iv_',num2str(num_ts),'(1:n_nodes*(num_tps-idx))];']);
    end
    Z_err_old=Z_err;
    Z_err=[Z_err_old;Z_err_one];
    clear Z_err_old
end


% define the Hessian
H=Z_err'*Z_err;

max_eig_H=max(abs(eig(H)));
min_eig_H=min(abs(eig(H)));

lambda_min=compute_lambada(min_eig_H,max_eig_H);

par_ar_no_model=(H+lambda_min*eye(size(H,1)))\Z_err'*X_err;

% if n_nodes==100
%     
%     % choose a good ridge parameter
%     % for big networks use just few time series (num_exp_4_lam)
%     %     num_exp_4_lam=2;
%     %     Z_err_lam=Z_err(1:n_nodes*(num_tps-1)*num_exp_4_lam,:);
%     %     X_err_lam=X_err(1:n_nodes*(num_tps-1)*num_exp_4_lam,:);
%     %     H_lam=Z_err_lam'*Z_err_lam;
%     %
%     %     max_eig_H_lam=max(eig(H_lam));
%     %     lambda_min=fminbnd(@(x_min)lambda_GCV(x_min,Z_err_lam,H_lam,Z_err_lam',X_err_lam),0,max_eig_H_lam/size(Z_err_lam,1));
%     %     lambda_min_t=lambda_min*size(Z_err_lam,1);
%     
%     vct_lambda=zeros(1,num_exp);
%     for num_exp_4_lam=1:num_exp
%         Z_err_lam=Z_err((num_exp_4_lam-1)*n_nodes*(num_tps-1)+1:n_nodes*(num_tps-1)*num_exp_4_lam,:);
%         X_err_lam=X_err((num_exp_4_lam-1)*n_nodes*(num_tps-1)+1:n_nodes*(num_tps-1)*num_exp_4_lam,:);
%         H_lam=Z_err_lam'*Z_err_lam;
% 
%         max_eig_H_lam=max(eig(H_lam));
%         lambda_min=fminbnd(@(x_min)lambda_GCV(x_min,Z_err_lam,H_lam,Z_err_lam',X_err_lam),0,max_eig_H_lam);
%         lambda_min_exp=lambda_min*size(Z_err_lam,1);
%         vct_lambda(num_exp_4_lam)=lambda_min_exp;
%     end
%     lambda_min_t=median(vct_lambda);
% else
% %     lambda_min=fminbnd(@(x_min)lambda_GCV(x_min,Z_err,H,Z_err',X_err),0,max_eig_H/size(Z_err,1));
%     
%     lambda_min=fminbnd(@(x_min)lambda_GCV(x_min,Z_err,H,Z_err',X_err),0,max_eig_H);
%     lambda_min_t=lambda_min*size(Z_err,1);
% end
% estimate the filter parameters
% par_ar_no_model=(H+lambda_min_t*eye(size(H,1)))\Z_err'*X_err;

par_ar_no_model=-par_ar_no_model;

Meas_mtx_flt_all=[];
for num_ts=1:num_exp
    % Filter the simulated Meas_sim with the AR filter
    Meas_sim_flt=zeros(n_time_pts,n_nodes);
    Meas_sim_ts=Meas_sim(n_time_pts*(num_ts-1)+1:n_time_pts*num_ts,:);
    for idx1=1:n_nodes
        for idx2=1:n_time_pts
            if idx2==1
                Meas_sim_flt(idx2,idx1)=Meas_sim_ts(idx2,idx1);
            elseif idx2>=2 && idx2<=ord_ar_no_model
                Meas_sim_flt(idx2,idx1)=Meas_sim_ts(idx2,idx1);
                for idx3=1:idx2-1
                    Meas_sim_flt_prev=Meas_sim_flt(idx2,idx1);
                    Meas_sim_flt(idx2,idx1)=Meas_sim_flt_prev+par_ar_no_model(idx3)*Meas_sim_ts(idx2-idx3,idx1);
                end
            elseif idx2>ord_ar_no_model
                Meas_sim_flt(idx2,idx1)=Meas_sim_ts(idx2,idx1);
                for idx3=1:ord_ar_no_model
                    Meas_sim_flt_prev=Meas_sim_flt(idx2,idx1);
                    Meas_sim_flt(idx2,idx1)=Meas_sim_flt_prev+par_ar_no_model(idx3)*Meas_sim_ts(idx2-idx3,idx1);
                end
            end
        end
    end
    Meas_mtx_flt_all_old=Meas_mtx_flt_all;
    Meas_mtx_flt_all=[Meas_mtx_flt_all_old;Meas_sim_flt];
end

