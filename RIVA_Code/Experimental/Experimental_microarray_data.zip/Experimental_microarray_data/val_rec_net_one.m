function A_id_net_cell= val_rec_net_one(Normal_A_id,num_criteria4delete)

n_nodes=size(Normal_A_id,1);

for idx2=1:n_nodes
    Normal_A_id(idx2,idx2)=0;
end

if num_criteria4delete==1
    
    inc_coef2add=1;%n_nodes/2;
    
    A_id_net_cell{(n_nodes-1)*(n_nodes/inc_coef2add)}=[];
        
    % Compute the edge ranking matrix (Constr_list)
    [idx_row, idx_col, val_coef]=find(Normal_A_id);
    [val_coef_sort, idx_sort]=sort(val_coef,'descend');
    Constr_list=[idx_row(idx_sort) idx_col(idx_sort) val_coef_sort];
    num_coef2add=0;
    A_id_net=eye(n_nodes);
    for num_net_id=1:(n_nodes-1)*(n_nodes/inc_coef2add)
        num_coef2add=num_coef2add+inc_coef2add;
        if num_coef2add>size(Constr_list,1) 
            num_coef2add=size(Constr_list,1);
        end
        for idx1=1:num_coef2add
            A_id_net(Constr_list(idx1,1),Constr_list(idx1,2))=1;%Constr_list(idx1,3);
        end
        A_id_net_cell{num_net_id}=A_id_net;
    end
    
else
     A_id_net_cell{(n_nodes-1)}=[];
     Indx_mtx=zeros(n_nodes,n_nodes);
     for idx1=1:n_nodes
         [val, ind]=sort(Normal_A_id(idx1,:),'descend');
         Indx_mtx(idx1,:)=ind;
     end
     A_id_net=eye(n_nodes);
     for num_net_id=1:n_nodes-1
     
         idx_col=Indx_mtx(:,num_net_id);
         for idx1=1:n_nodes
             A_id_net(idx1,idx_col(idx1))=Normal_A_id(idx1,idx_col(idx1));
         end
         A_id_net_cell{num_net_id}=A_id_net;
     end
end
