%% dynGenie3_Statistical Analysis

NameNetwork = {'Ecoli1', 'Ecoli2', 'Yeast1', 'Yeast2', 'Yeast3'};
NumberExperiment = 5;

ResultSA_dynGenie3 = {};
folderc = cd;

for rete = 1 : length(NameNetwork)
    
    goldfile = strcat(dolderc, '/GoldStandard/InSilicoSize100-', NameNetwork{rete}, '_goldstandard.tsv');
    gold_data = load_dream_network(goldfile);
   
    disp('**************************************************************')
    disp(['Current Network ' NameNetwork{rete}])
    disp('**************************************************************')
    


    for experiment = 1 : NumberExperiment

        filename = strcat(folderc, 'Ranking/', NameNetwork{rete}, '_dynGenie3_100_Experiment', num2str(experiment), '.txt');

        % load predictions
        test_data = load_dream_network(filename);
        
        % calculate performance metrics
        [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);
        
    
        ResultSA_dynGenie3.(NameNetwork{rete}).aupr{experiment} = aupr;
        ResultSA_dynGenie3.(NameNetwork{rete}).auroc{experiment} = auroc;
        ResultSA_dynGenie3.(NameNetwork{rete}).prec{experiment} = prec;
        ResultSA_dynGenie3.(NameNetwork{rete}).rec{experiment} = rec;
        ResultSA_dynGenie3.(NameNetwork{rete}).tpr{experiment} = tpr;
        ResultSA_dynGenie3.(NameNetwork{rete}).fpr{experiment} = fpr;
        ResultSA_dynGenie3.(NameNetwork{rete}).p_auroc{experiment} = p_auroc;
        ResultSA_dynGenie3.(NameNetwork{rete}).p_aupr{experiment} = p_aupr;

    end

end

