%% dynGenie3 application

% close all;
% clear all;
% clc;

%% Load Data

load DataGenie3.mat;

ResultdynGenie3 = {};

NumberNetworks = 5;
NumberGene = 100;
NumberTimePoint = 21;
NumberPerturbation = 10;
NumberExperiments = 5;
Network = {'Ecoli1', 'Ecoli2', 'Yeast1', 'Yeast2', 'Yeast3'};

% Index
index_node  = linspace(1, 100, 100); 
time_point = {[0:25:500], [0:25:500],[0:25:500], [0:25:500],[0:25:500], [0:25:500],[0:25:500], [0:25:500],[0:25:500], [0:25:500]};
tic
for rete = 1 : NumberNetworks
    
    disp('**************************************************************')
    disp(['Current Network ' Network{rete}])
    disp('**************************************************************')
    
    for experiment = 1 : NumberExperiments
        
        disp('**************************************************************')
        disp(['Current Experiments ' num2str(experiment)])
        disp('**************************************************************')

        
        [A, alphas] = dynGENIE3(DataGenie3.(Network{rete}){experiment},time_point);
        ResultdynGenie3.(Network{rete}){experiment} = A;
    end
    
end
exctime = toc;
save('ResultdynGenie3.mat', 'ResultdynGenie3');