%% 
clear all;
close all;
clc;

%% dynGenie3

load('ResultdynGenie3.mat')

NumberGen = 100;
NameNetwork = {'Ecoli1', 'Ecoli2', 'Yeast1', 'Yeast2', 'Yeast3'};
NumberNetwork = 5;
NumberExperiment = 5;


old_path = cd;
current_folder = cd;

for rete = 1 : NumberNetwork
    
       for experiment = 1 : NumberExperiment
    
        filename = strcat(NameNetwork{rete}, '_dynGenie3_100_Experiment', num2str(experiment), '.txt');
        
        folder_path = strcat(current_folder, '/Ranking');
        
        cd(folder_path)        
        get_link_list(ResultdynGenie3_monte.(NameNetwork{rete}){experiment}, linspace(1, 100, 100), {}, 0, filename)
        cd(old_path)
        
       end
    
end
