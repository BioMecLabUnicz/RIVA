%% Bingo Statistical Analysis

clear all;

NameNetwork = {'Ecoli1', 'Ecoli2', 'Yeast1', 'Yeast2', 'Yeast3'};

ResultSABingo = {};
folderc = cd;

for rete = 1 : length(NameNetwork)
    
 
    % the gold standard that corresponds to the testfile
    goldfile = strcat(folderc, '/GoldStandard/DREAM4_GoldStandard_InSilico_Size100_', num2str(rete),'.tsv');
    gold_data = load_dream_network(goldfile);

    disp('**************************************************************')
    disp(['Current Network ' NameNetwork{rete}])
    disp('**************************************************************')
    
    
        % predictions to be evaluated
        filename = strcat(folderc, '/Ranking/', NameNetwork{rete}, '_Bingo_100_Experiment.txt');
        % load predictions
        test_data = load_dream_network(filename);
        
        % calculate performance metrics
        [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);
        
    
        ResultSABingo.(NameNetwork{rete}).aupr = aupr;
        ResultSABingo.(NameNetwork{rete}).auroc = auroc;
        ResultSABingo.(NameNetwork{rete}).prec = prec;
        ResultSABingo.(NameNetwork{rete}).rec = rec;
        ResultSABingo.(NameNetwork{rete}).tpr = tpr;
        ResultSABingo.(NameNetwork{rete}).fpr = fpr;
        ResultSABingo.(NameNetwork{rete}).p_auroc = p_auroc;
        ResultSABingo.(NameNetwork{rete}).p_aupr = p_aupr;

    end

 %   save('ResultSABingo100_dream4.mat', 'ResultSABingo')



