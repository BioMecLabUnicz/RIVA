%% Bingo_Statistical Analysis

clear all;

NameNetwork = {'Ecoli1', 'Ecoli2', 'Yeast1', 'Yeast2', 'Yeast3'};

ResultSABingo = {};
folderc = cd;

for rete = 1 : length(NameNetwork)
    
    for n = 1 : 5
        
        % the gold standard that corresponds to the testfile
        goldfile = strcat(folderc, '/GoldStandard/InSilicoSize100-', NameNetwork{rete}, '_goldstandard.tsv');    % load gold standard
        gold_data = load_dream_network(goldfile);

        disp('**************************************************************')
        disp(['Current Network ' NameNetwork{rete}])
        disp('**************************************************************')
        
        
        % predictions to be evaluated
        filename = strcat(folderc, '/Ranking/', NameNetwork{rete}, '_Bingo_100_Experiment', num2str(n),'.txt');
        % load predictions
        test_data = load_dream_network(filename);
        
        % calculate performance metrics
        [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);
        
        
        ResultSABingo.(NameNetwork{rete}).aupr(n) = aupr;
        ResultSABingo.(NameNetwork{rete}).auroc(n) = auroc;
        
    end
    
end

%    save('ResultSABingo.mat', 'ResultSABingo')

