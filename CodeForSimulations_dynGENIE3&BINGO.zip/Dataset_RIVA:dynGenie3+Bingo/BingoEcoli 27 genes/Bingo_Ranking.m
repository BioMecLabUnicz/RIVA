%% 
clear all;
close all;
clc;

%% Bingo

load('R_8.mat')
load('R_10.mat')
load('R_15.mat')

NumberGen = 100;

NumberExperiment = 20;

old_path = cd;
current_folder = cd;

    
for experiment = 1 : NumberExperiment

    folder_path = strcat(current_folder, '/Ranking');

    filename = strcat('EMTAB643_8_experiment', num2str(experiment), '.txt');      
    cd(folder_path)
    getLinkList(R_8.EMTAB643{experiment}, linspace(1, 27, 27), {}, 0, filename);
    cd(old_path)
    cd(folder_path)
    filename = strcat('EMTAB1908_8_experiment', num2str(experiment), '.txt');
    getLinkList(R_8.EMTAB1908{experiment}, linspace(1, 27, 27), {}, 0, filename);
    cd(old_path)
    cd(folder_path)
    filename = strcat('EMTAB643_1908_8_experiment', num2str(experiment), '.txt');
    getLinkList(R_8.EMTAB643_1908{experiment}, linspace(1, 27, 27), {}, 0, filename);        
    cd(old_path)
    cd(folder_path)
    filename = strcat('EMTAB643_10_experiment', num2str(experiment), '.txt');
    getLinkList(R_10.EMTAB643{experiment}, linspace(1, 27, 27), {}, 0, filename);
    cd(old_path)
    cd(folder_path)
    filename = strcat('EMTAB1908_10_experiment', num2str(experiment), '.txt');
    getLinkList(R_10.EMTAB1908{experiment}, linspace(1, 27, 27), {}, 0, filename);
    cd(old_path)
    cd(folder_path)
    filename = strcat('EMTAB643_1908_10_experiment', num2str(experiment), '.txt');
    getLinkList(R_10.EMTAB643_1908{experiment}, linspace(1, 27, 27), {}, 0, filename);   
    cd(old_path)
    cd(folder_path)
    filename = strcat('EMTAB643_15_experiment', num2str(experiment), '.txt');
    getLinkList(R_15.EMTAB643{experiment}, linspace(1, 27, 27), {}, 0, filename);
    cd(old_path)
    cd(folder_path)
    filename = strcat('EMTAB1908_15_experiment', num2str(experiment), '.txt');
    getLinkList(R_15.EMTAB1908{experiment}, linspace(1, 27, 27), {}, 0, filename);
    cd(old_path)
    cd(folder_path)
    filename = strcat('EMTAB643_1908_15_experiment', num2str(experiment), '.txt');
    getLinkList(R_15.EMTAB643_1908{experiment}, linspace(1, 27, 27), {}, 0, filename);          
    cd(old_path)
    cd(folder_path)
    cd(old_path)

end