%% Bingo_Statistical Analysis

%clear all;


ResultSABingo_exp_8 = {};
ResultSABingo_exp_10 = {};
ResultSABingo_exp_15 = {};

folderc = cd;

% the gold standard that corresponds to the testfile
goldfile = strcat(folderc, '/GoldStandard/original_network.txt');
%load gold standard
gold_data = load_dream_network(goldfile);


for experiment = 1 : 20
   
    %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc,'/Ranking/EMTAB643_8_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);

    ResultSABingo_exp_8.EMTAB643.aupr{experiment} = aupr;
    ResultSABingo_exp_8.EMTAB643.auroc{experiment} = auroc;
    %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc,'/Ranking/EMTAB1908_8_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);
    ResultSABingo_exp_8.EMTAB1908.aupr{experiment} = aupr;
    ResultSABingo_exp_8.EMTAB1908.auroc{experiment} = auroc;
    %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc,'/Ranking/EMTAB643_1908_8_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);
    ResultSABingo_exp_8.EMTAB643_1908.aupr{experiment} = aupr;
    ResultSABingo_exp_8.EMTAB643_1908.auroc{experiment} = auroc;
    
    %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc,'/Ranking/EMTAB643_10_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);

    ResultSABingo_exp_10.EMTAB643.aupr{experiment} = aupr;
    ResultSABingo_exp_10.EMTAB643.auroc{experiment} = auroc;
    %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc,'/Ranking/EMTAB1908_10_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);
    ResultSABingo_exp_10.EMTAB1908.aupr{experiment} = aupr;
    ResultSABingo_exp_10.EMTAB1908.auroc{experiment} = auroc;
    %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc,'/Ranking/EMTAB643_1908_10_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);
    ResultSABingo_exp_10.EMTAB643_1908.aupr{experiment} = aupr;
    ResultSABingo_exp_10.EMTAB643_1908.auroc{experiment} = auroc;    
    
      %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc,'/Ranking/EMTAB643_15_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);

    ResultSABingo_exp_15.EMTAB643.aupr{experiment} = aupr;
    ResultSABingo_exp_15.EMTAB643.auroc{experiment} = auroc;
    %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc,'/Ranking/EMTAB1908_15_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);
    ResultSABingo_exp_15.EMTAB1908.aupr{experiment} = aupr;
    ResultSABingo_exp_15.EMTAB1908.auroc{experiment} = auroc;
    %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc,'/Ranking/EMTAB643_1908_15_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);
    ResultSABingo_exp_15.EMTAB643_1908.aupr{experiment} = aupr;
    ResultSABingo_exp_15.EMTAB643_1908.auroc{experiment} = auroc;     
    
    end

%    save('ResultSABingo_100.mat', 'ResultSABingo_100')





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Boxplot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

aupr_8 = [ cell2mat(ResultSABingo_exp_8.EMTAB643.aupr);  cell2mat(ResultSABingo_exp_8.EMTAB1908.aupr); cell2mat(ResultSABingo_exp_8.EMTAB643_1908.aupr)]; 
auroc_8 = [cell2mat(ResultSABingo_exp_8.EMTAB643.auroc); cell2mat(ResultSABingo_exp_8.EMTAB1908.auroc); cell2mat(ResultSABingo_exp_8.EMTAB643_1908.auroc)];
%  
aupr_10 = [ cell2mat(ResultSABingo_exp_10.EMTAB643.aupr);  cell2mat(ResultSABingo_exp_10.EMTAB1908.aupr); cell2mat(ResultSABingo_exp_10.EMTAB643_1908.aupr)]; 
auroc_10 = [cell2mat(ResultSABingo_exp_10.EMTAB643.auroc); cell2mat(ResultSABingo_exp_10.EMTAB1908.auroc); cell2mat(ResultSABingo_exp_10.EMTAB643_1908.auroc)]; 
 
aupr_15 = [ cell2mat(ResultSABingo_exp_15.EMTAB643.aupr);  cell2mat(ResultSABingo_exp_15.EMTAB1908.aupr); cell2mat(ResultSABingo_exp_15.EMTAB643_1908.aupr)]; 
auroc_15 = [cell2mat(ResultSABingo_exp_15.EMTAB643.auroc); cell2mat(ResultSABingo_exp_15.EMTAB1908.auroc); cell2mat(ResultSABingo_exp_15.EMTAB643_1908.auroc)];