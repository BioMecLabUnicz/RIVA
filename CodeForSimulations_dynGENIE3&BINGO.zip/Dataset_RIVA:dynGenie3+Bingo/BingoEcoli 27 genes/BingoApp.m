function R = BingoApp(mat1, time1,  mat2, time2)

    
    R = {};

    NumberGene = 27;
    NumberExperiments = 20;
    n = length(time2);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   for experiment = 1 : NumberExperiments
       
        disp('**************************************************************')
        disp(['Current Network EMTAB 643'])
        disp('**************************************************************')

        data.ts = {mat1{1,experiment}};
        data.Tsam = {time1};
        %initialization
        [data,state,parameters]=BINGO_init(data);

        % MCMC Burn-in
        [~,chain,~,state,stats]=BINGO(data,state,parameters);
        disp_stats(' BURN-IN COMPLETE',stats,chain,parameters.its)

        % Actual sampling
        parameters.its=10000;
        [Plink,chain,xstore,state,stats]=BINGO(data,state,parameters);
        disp_stats(' SAMPLING COMPLETE',stats,chain,parameters.its)

        %The end result:
        confidence_matrix=Plink/chain;
        %Store old information
        
        chain_old=chain;
        Plink_old=Plink;
        xstore_old=xstore;

        %Run new iterations
        parameters.its=50000;
        [Plink,chain,xstore,state,stats]=BINGO(data,state,parameters);

        %Combine old and new results
        xstore=chain_old/(chain+chain_old)*xstore_old+chain/(chain+chain_old)*xstore;
        Plink=Plink_old+Plink;
        chain=chain_old+chain;
        disp_stats(' SAMPLING COMPLETE',stats,chain,parameters.its)

        %The end result:
        confidence_matrix=Plink/chain;
        R.EMTAB643{experiment}= confidence_matrix;
        
        
        
        disp('**************************************************************')
        disp(['Current Network EMTAB 1908'])
        disp('**************************************************************')

        data.ts = {mat2{2,experiment}(:,1:n)};
        data.Tsam = {time2};
                %initialization
        [data,state,parameters]=BINGO_init(data);

        % MCMC Burn-in
        [~,chain,~,state,stats]=BINGO(data,state,parameters);
        disp_stats(' BURN-IN COMPLETE',stats,chain,parameters.its)

        % Actual sampling
        parameters.its=10000;
        [Plink,chain,xstore,state,stats]=BINGO(data,state,parameters);
        disp_stats(' SAMPLING COMPLETE',stats,chain,parameters.its)

        %The end result:
        confidence_matrix=Plink/chain;
        %Store old information
        
        chain_old=chain;
        Plink_old=Plink;
        xstore_old=xstore;

        %Run new iterations
        parameters.its=50000;
        [Plink,chain,xstore,state,stats]=BINGO(data,state,parameters);

        %Combine old and new results
        xstore=chain_old/(chain+chain_old)*xstore_old+chain/(chain+chain_old)*xstore;
        Plink=Plink_old+Plink;
        chain=chain_old+chain;
        disp_stats(' SAMPLING COMPLETE',stats,chain,parameters.its)

        %The end result:
        confidence_matrix=Plink/chain;
        R.EMTAB1908{experiment}= confidence_matrix;
        
        
        disp('**************************************************************')
        disp(['Current Network EMTAB 643-1908'])
        disp('**************************************************************')

        data.ts = {mat1{1, experiment}, mat2{2,experiment}(:,1:n)};
        data.Tsam = {time1, time2};
                %initialization
        [data,state,parameters]=BINGO_init(data);

        % MCMC Burn-in
        [~,chain,~,state,stats]=BINGO(data,state,parameters);
        disp_stats(' BURN-IN COMPLETE',stats,chain,parameters.its)

        % Actual sampling
        parameters.its=10000;
        [Plink,chain,xstore,state,stats]=BINGO(data,state,parameters);
        disp_stats(' SAMPLING COMPLETE',stats,chain,parameters.its)

        %The end result:
        confidence_matrix=Plink/chain;
        %Store old information
        
        chain_old=chain;
        Plink_old=Plink;
        xstore_old=xstore;

        %Run new iterations
        parameters.its=50000;
        [Plink,chain,xstore,state,stats]=BINGO(data,state,parameters);

        %Combine old and new results
        xstore=chain_old/(chain+chain_old)*xstore_old+chain/(chain+chain_old)*xstore;
        Plink=Plink_old+Plink;
        chain=chain_old+chain;
        disp_stats(' SAMPLING COMPLETE',stats,chain,parameters.its)

        %The end result:
        confidence_matrix=Plink/chain;        
             
        
        R.EMTAB643_1908{experiment}= confidence_matrix;

   end

end
