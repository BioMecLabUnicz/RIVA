%% Genie3_Statistical Analysis

clear all;


ResultSAdynGenie3 = {};

load('Ecoli_goldstandard.mat')
filename = 'Ecoli1565_dynGenie3_Experiment.txt';

% load predictions
test_data = load_dream_network(filename);
gold_data = original_network;
% calculate performance metrics
[aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);


ResultSAdynGenie3.aupr = aupr;
ResultSAdynGenie3.auroc = auroc;
ResultSAdynGenie3.prec = prec;
ResultSAdynGenie3.rec = rec;
ResultSAdynGenie3.tpr = tpr;
ResultSAdynGenie3.fpr = fpr;
ResultSAdynGenie3.p_auroc = p_auroc;
ResultSAdynGenie3.p_aupr = p_aupr;
