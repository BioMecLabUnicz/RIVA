%% 
clear all;
close all;
clc;

%% dynGenie3

load('ResultdyGenie3.mat')
filename = 'Ecoli1565_dynGenie3_Experiment.txt';
get_link_list(ResultdynGenie3{1,1}.VIM, linspace(1, 1565, 1565), {}, 0, filename)

 