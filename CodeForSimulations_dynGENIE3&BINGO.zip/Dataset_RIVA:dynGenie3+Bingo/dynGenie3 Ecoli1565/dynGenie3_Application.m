%% dynGenie3 application

% close all;
% clear all;
% clc;

%% Load Data

load Ecoli.mat;

NumberGene = size(Ecoli{1}{1},2);
NumberExperiments = 3; 
NumberTimePoints = 51;
NumberPerturbations = 39;

time_point = linspace(0, 50, 51);
time_points = {};
for i = 1 : NumberPerturbations
    time_points{i} = time_point;
end

tic
for exp = 1 

    [VIM, alphas] = dynGENIE3(Ecoli{exp},time_points);   
    ResultdynGenie3{experiment}.VIM = VIM;
    ResultdynGenie3{experiment}.alphas = alphas;
  
end
valt = toc;
ResultdynGenie3{2}.tempoexc = valt;
save('ResultdyGenie3.mat', 'ResultdynGenie3');
