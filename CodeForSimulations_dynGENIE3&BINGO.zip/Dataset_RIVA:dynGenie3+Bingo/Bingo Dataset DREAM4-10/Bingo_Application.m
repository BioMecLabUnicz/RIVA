%% Bingo application

% close all;
% clear all;
% clc;

%% Load Data
load('DataBingo_10.mat')
load('time_points_10.mat')

ResultBingo = {};

NumberNetworks = 5;
NumberGene = 10;
NumberTimePoint = 21;
Network = {'Ecoli1', 'Ecoli2', 'Yeast1', 'Yeast2', 'Yeast3'};


for rete = 1 : NumberNetworks
    
        disp('**************************************************************')
        disp(['Current Network ' Network{rete}])
        disp('**************************************************************')

        data.ts = DataBingo_10.(Network{rete});
        data.Tsam = time_points_10.(Network{rete});
                %initialization
        [data,state,parameters]=BINGO_init(data);

        % MCMC Burn-in
        [~,chain,~,state,stats]=BINGO(data,state,parameters);
        disp_stats(' BURN-IN COMPLETE',stats,chain,parameters.its)

        % Actual sampling
        parameters.its=10000;
        [Plink,chain,xstore,state,stats]=BINGO(data,state,parameters);
        disp_stats(' SAMPLING COMPLETE',stats,chain,parameters.its)

        %The end result:
        confidence_matrix=Plink/chain;
        %Store old information
        
        chain_old=chain;
        Plink_old=Plink;
        xstore_old=xstore;

        %Run new iterations
        parameters.its=50000;
        [Plink,chain,xstore,state,stats]=BINGO(data,state,parameters);

        %Combine old and new results
        xstore=chain_old/(chain+chain_old)*xstore_old+chain/(chain+chain_old)*xstore;
        Plink=Plink_old+Plink;
        chain=chain_old+chain;
        disp_stats(' SAMPLING COMPLETE',stats,chain,parameters.its)

        %The end result:
        confidence_matrix=Plink/chain;

        
        ResultBingo.(Network{rete}).A = confidence_matrix;

    end
    
save('ResultBingo_10.mat', 'ResultBingo');