%% 
clear all;
close all;
clc;

%% Bingo

load('ResultBingo_10.mat')

NumberGen = 10;
NameNetwork = {'Ecoli1', 'Ecoli2', 'Yeast1', 'Yeast2', 'Yeast3'};
NumberNetwork = 5;

old_path = cd;
current_folder = cd;

for rete = 1 : NumberNetwork
     
        filename = strcat(NameNetwork{rete}, '_Bingo_10_Experiment.txt');        
        folder_path = strcat(current_folder, '/Ranking');        
        cd(folder_path)        
        getLinkList(ResultBingo.(NameNetwork{rete}).A, linspace(1, 10, 10), {}, 0, filename); 
        cd(old_path)

    
end
