function R = dynGeniApp(mat1, time1,  mat2, time2)

    
    R = {};

    NumberGene = 27;
    NumberExperiments = 50;
    
    n = length(time2);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   for experiment = 1 : NumberExperiments

        R.EMTAB643{experiment}= dynGENIE3({mat1{1,experiment}'}, {time1}); % abbiamo considerato il primo set di dati, etichettato con A che corrisponde alla prima riga
        R.EMTAB1908{experiment}= dynGENIE3({mat2{2,experiment}(:,1:n)'}, {time2}); % abbiamo considerato il secondo set di dati, etichettato con L che corrisponde alla seconda riga
        R.EMTAB643_1908{experiment}= dynGENIE3({mat1{1,experiment}', mat2{2,experiment}(:,1:n)'}, {time1, time2});

   end

end

    