function R = GeniApp(mat1, time1,  mat2, time2)

    
    R = {};

    NumberGene = 27;
    NumberExperiments = 50;

    % Use Extra-Trees method
    tree_method='ET';

    % Number of trees per ensemble
    ntrees = 100;

    % Number of potential regulators for each node of a tree
    k = NumberGene -1;

    % Index
    index_node  = linspace(1, 27, 27); 
    n = length(time2);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %% 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   for experiment = 1 : NumberExperiments

        R.EMTAB643{experiment}= dynGENIE3({mat1{1,experiment}'}, {time1}); % abbiamo considerato il primo set di dati, etichettato con A che corrisponde alla prima riga
        R.EMTAB1908{experiment}= dynGENIE3({mat2{2,experiment}(:,1:n)'}, {time2}); % abbiamo considerato il secondo set di dati, etichettato con L che corrisponde alla seconda riga
        R.EMTAB643_1908{experiment}= dynGENIE3({mat1{1,experiment}', mat2{2,experiment}(:,1:n)'}, {time1, time2});

   end

end

    