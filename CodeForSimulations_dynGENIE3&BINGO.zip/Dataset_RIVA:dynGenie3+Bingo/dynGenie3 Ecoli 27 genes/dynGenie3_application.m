%% dynGENIE3 Application

close all;
clc;

%% Load Data

load('emtab_643_8.mat')
load('emtab_643_10.mat')
load('emtab_643_15.mat')
load('emtab_1908_L_8.mat')
load('emtab_1908_L_10.mat')
load('emtab_1908_L_15.mat')


%% dynGenie3 application:
% EMTAB 1908 L and T
time1 = 0.33:8:120;
time2 = 5:8:205;

R_8 = dynGeniApp(emtab_643_8, time1, emtab_1908_L_8, time2(1:14));

time1 = 0.33:10:120;
time2 = 5:10:205;

R_10 = dynGeniApp(emtab_643_10, time1, emtab_1908_L_10, time2(1:11));

time1 = 0.33:15:120;
time2 = 5:15:205;

R_15 = dynGeniApp(emtab_643_15, time1, emtab_1908_L_15, time2(1:8));

%% Save data
    
save('R_8.mat', 'R_8')
save('R_10.mat', 'R_10')
save('R_15.mat', 'R_15')


