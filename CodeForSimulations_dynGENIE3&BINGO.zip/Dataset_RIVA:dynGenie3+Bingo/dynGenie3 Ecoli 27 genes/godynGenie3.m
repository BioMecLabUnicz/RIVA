%% dynGenie3_Statistical Analysis

%clear all;


ResultSAdynGenie3_exp_8 = {};
ResultSAdynGenie3_exp_10 = {};
ResultSAdynGenie3_exp_15 = {};
folderc = cd;

% the gold standard that corresponds to the testfile
goldfile = strcat(folderc,'/GoldStandard/original_network.txt');
% load gold standard
gold_data = load_dream_network(goldfile);

for experiment = 1 : 50
   
    %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc, '/Ranking/EMTAB643_8_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);

    ResultSAdynGenie3_exp_8.EMTAB643.aupr{experiment} = aupr;
    ResultSAdynGenie3_exp_8.EMTAB643.auroc{experiment} = auroc;
    %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc, '/Ranking/EMTAB1908_8_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);
    ResultSAdynGenie3_exp_8.EMTAB1908.aupr{experiment} = aupr;
    ResultSAdynGenie3_exp_8.EMTAB1908.auroc{experiment} = auroc;
    %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc, '/Ranking/EMTAB643_1908_8_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);
    ResultSAdynGenie3_exp_8.EMTAB643_1908.aupr{experiment} = aupr;
    ResultSAdynGenie3_exp_8.EMTAB643_1908.auroc{experiment} = auroc;
    
    %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc, '/Ranking/EMTAB643_10_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);

    ResultSAdynGenie3_exp_10.EMTAB643.aupr{experiment} = aupr;
    ResultSAdynGenie3_exp_10.EMTAB643.auroc{experiment} = auroc;
    %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc, '/Ranking/EMTAB1908_10_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);
    ResultSAdynGenie3_exp_10.EMTAB1908.aupr{experiment} = aupr;
    ResultSAdynGenie3_exp_10.EMTAB1908.auroc{experiment} = auroc;
    %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc, '/Ranking/EMTAB643_1908_10_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);
    ResultSAdynGenie3_exp_10.EMTAB643_1908.aupr{experiment} = aupr;
    ResultSAdynGenie3_exp_10.EMTAB643_1908.auroc{experiment} = auroc;    
    
      %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc, '/Ranking/EMTAB643_15_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);

    ResultSAdynGenie3_exp_15.EMTAB643.aupr{experiment} = aupr;
    ResultSAdynGenie3_exp_15.EMTAB643.auroc{experiment} = auroc;
    %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc, '/Ranking/EMTAB1908_15_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);
    ResultSAdynGenie3_exp_15.EMTAB1908.aupr{experiment} = aupr;
    ResultSAdynGenie3_exp_15.EMTAB1908.auroc{experiment} = auroc;
    %%%% EMTAB
    
    % predictions to be evaluated
    filename = strcat(folderc, '/Ranking/EMTAB643_1908_15_experiment', num2str(experiment), '.txt');
    test_data = load_dream_network(filename);
    [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data);
    ResultSAdynGenie3_exp_15.EMTAB643_1908.aupr{experiment} = aupr;
    ResultSAdynGenie3_exp_15.EMTAB643_1908.auroc{experiment} = auroc;     
    
    end

