%% dynGenie3 application

% close all;
% clear all;
% clc;

%% Load Data
load('dynDataGenie3_100_11.mat')
load('time_points_100_11.mat')

ResultdynGenie3_100 = {};

NumberNetworks = 5;
NumberGene = 100;
NumberTimePoint = 21;
NumberExperiments = 10;
Network = {'Ecoli1', 'Ecoli2', 'Yeast1', 'Yeast2', 'Yeast3'};

% Index
index_node  = linspace(1, 100, 100); 

for rete = 1 : NumberNetworks
    
    disp('**************************************************************')
    disp(['Current Network ' Network{rete}])
    disp('**************************************************************')
    

    [A, alpha] = dynGENIE3(dynDataGenie3_100.(Network{rete}), time_points_100.(Network{rete}),'from_data',[],linspace(1,NumberGene, NumberGene));
            
        ResultdynGenie3_100.(Network{rete}).A = A;
        ResultdynGenie3_100.(Network{rete}).alpha = alpha;

end
    
save('ResultdynGenie3_100_11.mat', 'ResultdynGenie3_100');

