%% 
clear all;
close all;
clc;

%% dynGenie3

load('ResultdynGenie3_10.mat');

NumberGen = 10;
NameNetwork = {'Ecoli1', 'Ecoli2', 'Yeast1', 'Yeast2', 'Yeast3'};
NumberNetwork = 5;

old_path = cd;
current_folder = cd;

for rete = 1 : NumberNetwork
  
        filename = strcat(NameNetwork{rete}, '_dynGenie3_Experiment.txt');
        folder_path = strcat(current_folder, '/Ranking');
        cd(folder_path)      
        get_link_list(ResultdynGenie3.(NameNetwork{rete}).A, linspace(1, 10, 10), {}, 0, filename);        
        cd(old_path)

end