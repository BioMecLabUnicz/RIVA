%% dynGenie3_Statistical Analysis

clear all;

NameNetwork = {'Ecoli1', 'Ecoli2', 'Yeast1', 'Yeast2', 'Yeast3'};

ResultSAdynGenie3 = {};
folderc = cd;
 
for rete = 1 : length(NameNetwork)
    
 
    % the gold standard that corresponds to the testfile
    goldfile = strcat(folderc, '/GoldStandard/DREAM4_GoldStandard_InSilico_Size10_', num2str(rete), '.tsv');    % load gold standard
    gold_data = load_dream_network(goldfile);

    
    disp('**************************************************************')
    disp(['Current Network ' NameNetwork{rete}])
    disp('**************************************************************')
    
    
        % predictions to be evaluated
        filename = strcat(folderc, '/Ranking/', NameNetwork{rete}, '_dynGenie3_Experiment.txt');
        % load predictions
        test_data = load_dream_network(filename);
        
        % calculate performance metrics
        [aupr auroc prec rec tpr fpr p_auroc p_aupr] = DREAM4_Challenge2_Evaluation(test_data, gold_data, pdf_data);
        
    
        ResultSAdynGenie3.Genie3.(NameNetwork{rete}).aupr = aupr;
        ResultSAdynGenie3.Genie3.(NameNetwork{rete}).auroc = auroc;
        ResultSAdynGenie3.Genie3.(NameNetwork{rete}).prec = prec;
        ResultSAdynGenie3.Genie3.(NameNetwork{rete}).rec = rec;
        ResultSAdynGenie3.Genie3.(NameNetwork{rete}).tpr = tpr;
        ResultSAdynGenie3.Genie3.(NameNetwork{rete}).fpr = fpr;
        ResultSAdynGenie3.Genie3.(NameNetwork{rete}).p_auroc = p_auroc;
        ResultSAdynGenie3.Genie3.(NameNetwork{rete}).p_aupr = p_aupr;

    end

