%% dynGenie3 application

% close all;
% clear all;
% clc;

%% Load Data
load('dynDataGenie3_10.mat')
load('time_points_10.mat')

ResultdynGenie3 = {};

NumberNetworks = 5;
NumberGene = 10;
NumberTimePoint = 11;
Network = {'Ecoli1', 'Ecoli2', 'Yeast1', 'Yeast2', 'Yeast3'};

% Index
index_node  = linspace(1, 10, 10); 

for rete = 1 : NumberNetworks
    
    disp('**************************************************************')
    disp(['Current Network ' Network{rete}])
    disp('**************************************************************')
    

    [A, alpha] = dynGENIE3(dynDataGenie3.(Network{rete}), time_points.(Network{rete}),'from_data',[],linspace(1,NumberGene, NumberGene));

    ResultdynGenie3.(Network{rete}).A = A;
    ResultdynGenie3.(Network{rete}).alpha = alpha;

    end
    
save('ResultdynGenie3_10.mat', 'ResultdynGenie3');
