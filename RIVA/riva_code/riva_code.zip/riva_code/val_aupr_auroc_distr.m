
function [AUPR_m, AUROC_m, PPV, Se, Sp, FP]=val_aupr_auroc_distr(original_network,A_id_cell,tag_norm)

n_nodes=size(original_network,1);
TN=(n_nodes-1)*n_nodes-nnz(original_network);


n_tests=size(A_id_cell(1,:),2);
n_nets=(n_nodes-1)*n_nodes;
A_id_all_nets_cell{n_tests,n_nets}=[];
for num_test=1:n_tests
    Normal_A_id = norm_rec_mtx(A_id_cell{1,num_test},tag_norm);
    
    
    A_id_net= val_rec_net_one(Normal_A_id,1);
    A_id_all_nets_cell(num_test,:)=A_id_net;
    
end

A_id_t_all=zeros(n_nodes,n_nodes);
for num_net=1:n_nets
    for num_test=1:n_tests
        A_id_t=A_id_all_nets_cell{num_test,num_net};
        A_id_t_all=A_id_t+A_id_t_all;
    end
end
A_id_net_cell= val_rec_net(A_id_t_all,1);

% the performance obtainded by A_id_all_nets_cell and A_id_nets_cell are
% the same since n_tests is equal to 1 for the tested cases 

PPV=zeros(1,size(A_id_net_cell,2));
Se=zeros(1,size(A_id_net_cell,2));
Sp=zeros(1,size(A_id_net_cell,2));
FP=zeros(1,size(A_id_net_cell,2));
for idx=1:size(A_id_net_cell,2)

    [Perf_idx, Res]= ppv_sens_spec(original_network,A_id_net_cell{idx});

    PPV(idx)=Perf_idx(2,1);
    Se(idx)=Perf_idx(2,2);
    Sp(idx)=Perf_idx(2,3);
    FP(idx)=size(Res.Dir.False_pos,1);

end
AUPR_m=eval_aupr(PPV,Se);
AUROC_m=eval_auroc(Se,FP,TN);
