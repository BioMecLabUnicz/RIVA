
function [AUPR_m, AUROC_m, PPV, Se, Sp, FP]=val_aupr_auroc_net100(original_network,A_id_cell,tag_norm)
%A_id_mean=zeros(n_nodes,n_nodes);

n_nodes=size(original_network,1);
TN=(n_nodes-1)*n_nodes-nnz(original_network);

% A_id_sum=zeros(n_nodes,n_nodes);
% n_tests=size(A_id_cell,2);
% for num_test=1:n_tests
%     A_id_num_test=A_id_cell{num_net,num_test};
%     Normal_A_id_num_test = norm_rec_mtx(A_id_num_test,tag_norm);
%     % A_id_sum=zeros(n_nodes,n_nodes);
%     A_id_sum_old=A_id_sum;
%     A_id_sum=A_id_sum_old+Normal_A_id_num_test;
%     
%     
% end


Normal_A_id = norm_rec_mtx(A_id_cell,tag_norm);
A_id_net_cell= val_rec_net_net100(Normal_A_id,1);
PPV=zeros(1,size(A_id_net_cell,2));
Se=zeros(1,size(A_id_net_cell,2));
Sp=zeros(1,size(A_id_net_cell,2));
FP=zeros(1,size(A_id_net_cell,2));
for idx=1:size(A_id_net_cell,2)

    [Perf_idx Res]= ppv_sens_spec(original_network,A_id_net_cell{idx});

    PPV(idx)=Perf_idx(2,1);
    Se(idx)=Perf_idx(2,2);
    Sp(idx)=Perf_idx(2,3);
    FP(idx)=size(Res.Dir.False_pos,1);

end
AUPR_m=eval_aupr(PPV,Se);
AUROC_m=eval_auroc(Se,FP,TN);


