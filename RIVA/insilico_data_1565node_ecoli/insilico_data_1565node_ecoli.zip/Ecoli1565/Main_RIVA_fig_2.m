% This script allows to generate the results shown in Fig. 2:
% Evaluation of the more likely reconstructed network
% among all those identified, for the in-silico Ecoli network of 1565 nodes 

% load the stored identified networks (20) obtained by running
% Main_RIVA_results_4_fig_2.m, using an in-silico data-set consisiting of
% 39 time-series of 51 time points, and replicating the simulated data-set
% 20 times
load Data_results_fig2/results/res_Riva_Ecoli1565.mat


A_id_cell_RLS_IV_tot=A_id_cell_RLS_IV; % the stored identified networks (20) by RIVA
sol_found_RLS_IV_tot=sol_found_RLS_IV;

aupr_Riva=zeros(1,n_networks);
auroc_Riva=zeros(1,n_networks);

n_networks=size(A_id_cell_RLS_IV_tot,1);
all_tests=size(A_id_cell_RLS_IV_tot,2);

% number of links to be added for computing performance at each evaluation (idx_eval): from 1 to 2447660=sum(inc_coef2add); 
inc_coef2add=[1:10, 15:5:50, 60:10:100 150:50:500 600:100:1000 2000:1000:10000 20000:10000:100000 200000:100000:500000 446345];

num_mode=1; %criterion of normalization for ranking, it can be also 2 or 3, see norm_rec_mtx.m


for num_id_net=1:n_networks
    num_id=0;
     Constr_list_cell_net=[];
    for num_test=1:all_tests
        sol_found_id=sol_found_RLS_IV_tot{num_id_net,num_test};
        
        if sol_found_id
            
            A_id_cell=A_id_cell_RLS_IV_tot{num_id_net,num_test};
            %normalize the identified matrix
            Normal_A_id = norm_rec_mtx(A_id_cell,num_mode);
            for idx2=1:n_nodes
                Normal_A_id(idx2,idx2)=0;
            end
            % sort the matrix coef.
            [idx_row, idx_col, val_coef]=find(Normal_A_id);
            [val_coef_sort, idx_sort]=sort(val_coef,'descend');
            %create the ranking list
            Constr_list=[idx_row(idx_sort) idx_col(idx_sort) val_coef_sort];
            
            num_id=num_id+1;
            % store the ranking list for a test
            Constr_list_cell_net{num_id}=Constr_list;
        end
                    
    end
    
    
    
    %load the original network
            
    load Data_results_fig2/Data/Ecoli_goldstandard.mat

            
    num_eval=length(inc_coef2add);
    PPV=zeros(1,num_eval);
    Se=zeros(1,num_eval);
    Sp=zeros(1,num_eval);
    FP=zeros(1,num_eval);
    TN=(n_nodes-1)*n_nodes-nnz(original_network);

    for idx_eval=1:num_eval
        
        A_n_rank=zeros(n_nodes,n_nodes); % each entry represents the number of times that the corresponding link exists for the tests at a given evaluation 
        num_edges=sum(inc_coef2add(1:idx_eval));% number of edges to be inserted from a given ranking list                     
        if not(isempty(Constr_list_cell_net))            
            
            for idx_id=1:size(Constr_list_cell_net,2) % for all the tests with solution
                rank_list=Constr_list_cell_net{idx_id}; 
               
                % for the entry of A_n_rank add 1 if the corresponding
                % edge is in the ranking list (of n edges, n=num_edges) for
                % the given test
                for idx_n=1:num_edges
                    
                    A_n_rank(rank_list(idx_n,1),rank_list(idx_n,2))=A_n_rank(rank_list(idx_n,1),rank_list(idx_n,2))+1;
                    
                    
                end
                
                
            end
        end
        
        A_n_rank_cell{num_id_net,idx_eval}=A_n_rank;
        A_id_ones=val_rec_list(A_n_rank,num_edges); % A matrix with entries equal to 1 corresponding to the n edges (n=num_edges) more likely 
        Perf_idx= ppv_sens_spec_dir(original_network,A_id_ones);
        
        PPV(idx_eval)=Perf_idx(1);
        Se(idx_eval)=Perf_idx(2);
        Sp(idx_eval)=Perf_idx(3);
        FP(idx_eval)=Perf_idx(4);
        
    end
            
    aupr_Riva(num_id_net)=eval_aupr(PPV,Se);
    auroc_Riva(num_id_net)=eval_auroc(Se,FP,TN);
                       
end


%%%%%% Plot the performance of RIVA and dynGenie3

 
load Data_results_fig2/results/dynGenie3_1565

tag_riva='ob';
tag_genie='sk';

for num_id_net=1
   
    
   
    
    if num_id_net==1
        name_net='E. coli 1565';
    end
    %
    
    f=figure;
    hold on 
    grid on
    plot(auroc_Riva(num_id_net),aupr_Riva(num_id_net),tag_riva,'linewidth',1.5);
    plot(Result_dynGenie3_1565.auroc(num_id_net),Result_dynGenie3_1565.aupr(num_id_net),tag_genie,'linewidth',1.5);
    xlim([0.5 0.8])
     
    ylim([0 0.007])
    ylabel('AUPR')
    xlabel('AUROC')
    title(name_net)
    set(f,'Position',[10 10 250 250])
    set(gca,'fontsize',12)
    
end



